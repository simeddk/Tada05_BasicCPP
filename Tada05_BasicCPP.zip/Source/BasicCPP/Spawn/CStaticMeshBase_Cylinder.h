#pragma once

#include "CoreMinimal.h"
#include "Spawn/CStaticMeshBase.h"
#include "CStaticMeshBase_Cylinder.generated.h"

UCLASS()
class BASICCPP_API ACStaticMeshBase_Cylinder : public ACStaticMeshBase
{
	GENERATED_BODY()

public:
	ACStaticMeshBase_Cylinder();
	
};
