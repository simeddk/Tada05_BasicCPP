#pragma once

#include "CoreMinimal.h"
#include "Spawn/CStaticMeshBase.h"
#include "CStaticMeshBase_Cone.generated.h"

UCLASS()
class BASICCPP_API ACStaticMeshBase_Cone : public ACStaticMeshBase
{
	GENERATED_BODY()

public:
	ACStaticMeshBase_Cone();
	
};
