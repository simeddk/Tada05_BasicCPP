#pragma once

#include "CoreMinimal.h"
#include "Spawn/CStaticMeshBase.h"
#include "CStaticMeshBase_Cube.generated.h"

UCLASS()
class BASICCPP_API ACStaticMeshBase_Cube : public ACStaticMeshBase
{
	GENERATED_BODY()

public:
	ACStaticMeshBase_Cube();
	
};
