#pragma once

#include "CoreMinimal.h"
#include "Spawn/CStaticMeshBase.h"
#include "CStaticMeshBase_Sphere.generated.h"

UCLASS()
class BASICCPP_API ACStaticMeshBase_Sphere : public ACStaticMeshBase
{
	GENERATED_BODY()

public:
	ACStaticMeshBase_Sphere();
	
};
