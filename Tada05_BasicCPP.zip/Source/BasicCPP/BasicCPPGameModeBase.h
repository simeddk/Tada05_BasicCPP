// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "BasicCPPGameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class BASICCPP_API ABasicCPPGameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
};
